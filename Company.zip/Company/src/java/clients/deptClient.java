/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/JerseyClient.java to edit this template
 */
package clients;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;

/**
 * Jersey REST client generated for REST resource:deptResource [dept]<br>
 * USAGE:
 * <pre>
 *        deptClient client = new deptClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author LENOVO
 */
public class deptClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/Company/webresources";

    public deptClient() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("dept");
    }

    public void insertdept(String name) throws ClientErrorException {
        webTarget.path(java.text.MessageFormat.format("insertdept/{0}", new Object[]{name})).request().post(null);
    }
    
        public void updatedept(String id, String name) throws ClientErrorException {
            Entity <?> empty = Entity.text("");
            webTarget.path(java.text.MessageFormat.format("updatedept/{0}/{1}", new Object[]{id, name})).request().put(empty);
        }
        
                public void deletedept(String id) throws ClientErrorException {
            webTarget.path(java.text.MessageFormat.format("deletedept/{0}", new Object[]{id})).request().delete();
        }
    public void close() {
        client.close();
    }
    
}
