/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package rest;

import ejb.deptbeanLocal;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author LENOVO
 */
@Path("dept")
public class deptResource {

    @Context
    private UriInfo context;
    
    @EJB deptbeanLocal dept;

    /**
     * Creates a new instance of deptResource
     */
    public deptResource() {
    }

    /**
     * Retrieves representation of an instance of rest.deptResource
     * @param <error>
     * @param deptname
     * @return an instance of java.lang.String
     */
    @POST
    @Path("/insertdept/{name}")
    public void insertdept(@PathParam("name")String deptname){
        dept.insertdept(deptname);
    }
    
    @PUT
    @Path("/updatedept/{id}/{name}")
    public void updatedept(@PathParam("id")Integer id, @PathParam("name")String deptname){
        dept.updatedept(id, deptname);
    }
    
    @DELETE
    @Path("/deletedept/{id}")
    public void deletedept(@PathParam("id")Integer id){
        dept.deletedept(id);
    }
}
