/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package beans;

import ejb.deptbeanLocal;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author LENOVO
 */
@Named(value = "newJSFManagedBean")
@RequestScoped
public class NewJSFManagedBean {

    @EJB
    private deptbeanLocal deptbean;
    
    Integer id;
    String name;
    
    //insrt code(getter & setter)
    
    public deptbeanLocal getDeptbean() {
        return deptbean;
    }

    public void setDeptbean(deptbeanLocal deptbean) {
        this.deptbean = deptbean;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    

    /**
     * Creates a new instance of NewJSFManagedBean
     */
    public NewJSFManagedBean() {
        
    }
    public void insertdept(){
        deptbean.insertdept(name);
    }
}
