/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Dept;
import entity.Emp;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author LENOVO
 */
@Stateless
public class empbean implements empbeanLocal 
{
    @PersistenceContext (unitName = "CompanyPU")
    EntityManager em;

    @Override
    public void insertemp(String e_name) 
    {
        Emp e = new Emp();
        e.setEName(e_name);
        em.persist(e);
       
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateemp(Integer e_id, Integer d_id, String e_name)
    {
        Emp e = new Emp();
        e.setEName(e_name);
        e.setEId(e_id);
        e.getDId(d_id);
        em.merge(e);
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteemp(Integer e_id) 
    {
        Emp e = em.find(Emp.class, e_id);
         em.remove(e);
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Emp> getemp() 
    {
       Collection<Emp> emps = em.createNamedQuery("Emp.findAll").getResultList();
        return emps;
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

   

   

    
}
