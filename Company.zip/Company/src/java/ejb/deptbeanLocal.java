/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package ejb;

import entity.Dept;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author LENOVO
 */
@Local
public interface deptbeanLocal 
{
    public void insertdept(String d_name);
    public void updatedept(Integer d_id,String d_name);
    public void deletedept(Integer d_id);
    public Collection<Dept> getdept();
}
