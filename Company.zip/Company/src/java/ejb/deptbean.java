/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Dept;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author LENOVO
 */
@Stateless
public class deptbean implements deptbeanLocal 
{
    @PersistenceContext (unitName = "CompanyPU")
    EntityManager em;
    

    @Override
    public void insertdept(String d_name) 
    {
        Dept d = new Dept();
        d.setDName(d_name);
        em.persist(d);
       
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updatedept(Integer d_id, String d_name) 
    {
        Dept d = new Dept();
        d.setDName(d_name);
        d.setDId(d_id);
        em.merge(d);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deletedept(Integer d_id) 
    {
         Dept d = em.find(Dept.class, d_id);
         em.remove(d);
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Dept> getdept() 
    {
        Collection<Dept> depts = em.createNamedQuery("Dept.findAll").getResultList();
        return depts;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
