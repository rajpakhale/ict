/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package ejb;

import entity.Dept;
import entity.Emp;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author LENOVO
 */
@Local
public interface empbeanLocal 
{
    public void insertemp(String e_name);
    public void updateemp(Integer e_id,Integer d_id,String e_name);
    public void deleteemp(Integer e_id);
    public Collection<Emp> getemp();

    
    
}
